package Animais;

public abstract class Ave extends Animal {
    public Ave(String nome) {
        super(nome);
    }
}
