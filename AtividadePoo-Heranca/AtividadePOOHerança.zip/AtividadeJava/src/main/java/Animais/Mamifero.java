package Animais;

public abstract class Mamifero extends Animal{
    public Mamifero(String nome) {
        super(nome);
    }
}
