package Animais;
public abstract class Carnivoro extends Animal {
    public Carnivoro(String nome) {
        super(nome);
    }
}