package Animais;

public abstract class Herbivoro extends Animal {
    public Herbivoro(String nome) {
        super(nome);
    }
}
