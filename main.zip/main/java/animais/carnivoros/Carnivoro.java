package animais.carnivoros;

import animais.Animal;

public abstract class Carnivoro extends Animal {
    public Carnivoro(String nome) {
        super(nome);
    }
}