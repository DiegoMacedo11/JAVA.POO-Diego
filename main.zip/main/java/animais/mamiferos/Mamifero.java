package animais.mamiferos;

import animais.Animal;

public abstract class Mamifero extends Animal {
    public Mamifero(String nome) {
        super(nome);
    }
}
