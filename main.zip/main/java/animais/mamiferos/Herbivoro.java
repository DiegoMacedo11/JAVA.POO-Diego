package animais.mamiferos;

import animais.Animal;

public abstract class Herbivoro extends Animal {
    public Herbivoro(String nome) {
        super(nome);
    }
}
