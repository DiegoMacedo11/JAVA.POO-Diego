package interfaces;

public interface Usb {
    void conectar();
}
