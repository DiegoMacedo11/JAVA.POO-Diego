package interfaces;

import java.sql.SQLOutput;

public class Mouse implements Usb{


    @Override
    public void conectar() {
        System.out.println("Conectar Mouse");
    }
}
